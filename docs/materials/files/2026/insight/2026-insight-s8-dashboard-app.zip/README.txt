설치: python -m pip install -r requirements.txt
실행: python -m streamlit run app.py
또는 Windows에서는 run_app.bat 더블클릭
