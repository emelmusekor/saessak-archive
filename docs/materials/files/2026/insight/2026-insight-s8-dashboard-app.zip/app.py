import time

import numpy as np
import pandas as pd
import pydeck as pdk
import requests
import streamlit as st


API_URL = "https://opensky-network.org/api/states/all"
TOKEN_URL = "https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token"

COLUMNS = [
    "icao24", "callsign", "origin_country", "time_position", "last_contact",
    "longitude", "latitude", "baro_altitude", "on_ground", "velocity",
    "true_track", "vertical_rate", "sensors", "geo_altitude", "squawk",
    "spi", "position_source"
]

REGION_PRESETS = {
    "한반도": {"lamin": 33.0, "lomin": 124.0, "lamax": 39.0, "lomax": 132.0, "zoom": 5},
    "한반도 + 일본 서부": {"lamin": 30.0, "lomin": 122.0, "lamax": 42.0, "lomax": 142.0, "zoom": 4},
    "동북아시아": {"lamin": 25.0, "lomin": 115.0, "lamax": 50.0, "lomax": 150.0, "zoom": 3},
}

st.set_page_config(page_title="AI 스마트 항공 관제탑", layout="wide")

for key, value in {
    "map_lat": 36.0,
    "map_lon": 128.0,
    "map_zoom": 5,
    "selected_icao24": None,
    "last_bounds_key": None,
}.items():
    if key not in st.session_state:
        st.session_state[key] = value


@st.cache_data(ttl=300)
def get_access_token(client_id: str, client_secret: str) -> str:
    response = requests.post(
        TOKEN_URL,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()["access_token"]


@st.cache_data(ttl=25)
def fetch_opensky_states(bounds_key: tuple, client_id: str = "", client_secret: str = "") -> pd.DataFrame:
    lamin, lomin, lamax, lomax = bounds_key
    headers = {}

    if client_id and client_secret:
        token = get_access_token(client_id, client_secret)
        headers["Authorization"] = f"Bearer {token}"

    response = requests.get(
        API_URL,
        params={"lamin": lamin, "lomin": lomin, "lamax": lamax, "lomax": lomax},
        headers=headers,
        timeout=20,
    )
    response.raise_for_status()

    data = response.json()

    if data.get("states") is None:
        return pd.DataFrame(columns=COLUMNS)

    df = pd.DataFrame(data["states"], columns=COLUMNS)
    df["callsign"] = df["callsign"].fillna("").astype(str).str.strip()
    return df


def analyse_danger(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
    df = df.copy()

    if df.empty:
        return df

    for col in ["vertical_rate", "latitude", "longitude", "baro_altitude", "velocity"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if df["on_ground"].dtype == "object":
        df["on_ground"] = (
            df["on_ground"]
            .astype(str)
            .str.lower()
            .str.strip()
            .isin(["true", "1", "yes"])
        )

    df = df[
        (df["on_ground"] == False) &
        (df["vertical_rate"].notna()) &
        (df["latitude"].notna()) &
        (df["longitude"].notna())
    ].copy()

    if df.empty:
        return df

    mean_vr = df["vertical_rate"].mean()
    std_vr = df["vertical_rate"].std(ddof=0)

    if pd.isna(std_vr) or std_vr == 0:
        df["z_score"] = 0.0
    else:
        df["z_score"] = (df["vertical_rate"] - mean_vr) / std_vr

    df["status"] = np.where(df["z_score"] <= threshold, "위험(급강하)", "정상")
    df = df.sort_values("z_score").reset_index(drop=True)
    df["number"] = df.index + 1
    return df


def build_map_data(df: pd.DataFrame) -> pd.DataFrame:
    map_df = df.copy()
    map_df["lat"] = map_df["latitude"]
    map_df["lon"] = map_df["longitude"]
    map_df["label"] = map_df["number"].astype(str)
    map_df["callsign"] = map_df["callsign"].replace("", "Unknown")
    map_df["color"] = map_df["status"].apply(
        lambda status: [255, 0, 0, 200] if status == "위험(급강하)" else [31, 119, 180, 180]
    )
    map_df["radius"] = map_df["status"].apply(
        lambda status: 14000 if status == "위험(급강하)" else 9000
    )
    map_df["label_color"] = [[255, 255, 255, 255] for _ in range(len(map_df))]
    return map_df


def make_deck(map_df: pd.DataFrame) -> pdk.Deck:
    point_layer = pdk.Layer(
        "ScatterplotLayer",
        data=map_df,
        id="aircraft-points",
        get_position="[lon, lat]",
        get_fill_color="color",
        get_radius="radius",
        pickable=True,
        auto_highlight=True,
    )

    label_layer = pdk.Layer(
        "TextLayer",
        data=map_df,
        id="aircraft-labels",
        get_position="[lon, lat]",
        get_text="label",
        get_size=16,
        get_color="label_color",
        get_text_anchor='"middle"',
        get_alignment_baseline='"center"',
        pickable=False,
    )

    view_state = pdk.ViewState(
        latitude=st.session_state.map_lat,
        longitude=st.session_state.map_lon,
        zoom=st.session_state.map_zoom,
        pitch=0,
    )

    tooltip = {
        "html": """
        <b>#{number} {callsign}</b><br/>
        상태: {status}<br/>
        국적: {origin_country}<br/>
        수직 승강률: {vertical_rate} m/s<br/>
        Z-score: {z_score}<br/>
        고도: {baro_altitude} m<br/>
        속도: {velocity} m/s
        """,
        "style": {"backgroundColor": "white", "color": "black"},
    }

    return pdk.Deck(
        layers=[point_layer, label_layer],
        initial_view_state=view_state,
        tooltip=tooltip,
        map_style=None,
    )


def extract_selected_aircraft(event):
    try:
        selected_objects = event.selection.objects.get("aircraft-points", [])
    except Exception:
        return None

    if not selected_objects:
        return None

    return selected_objects[0]


def render_selected_aircraft(selected_row: pd.DataFrame):
    if selected_row.empty:
        st.info("지도에서 항공기 점을 클릭하면 이곳에 상세 정보가 표시됩니다.")
        return

    row = selected_row.iloc[0]
    st.write(f"번호: {int(row['number'])}")
    st.write(f"항공편명: {row['callsign'] if row['callsign'] else 'Unknown'}")
    st.write(f"상태: {row['status']}")
    st.write(f"국적: {row['origin_country']}")
    st.write(f"수직 승강률: {row['vertical_rate']:.2f} m/s")
    st.write(f"Z-score: {row['z_score']:.2f}")
    st.write(f"고도: {row['baro_altitude']} m")
    st.write(f"속도: {row['velocity']} m/s")
    st.write(f"위도: {row['latitude']}")
    st.write(f"경도: {row['longitude']}")


st.title("AI 스마트 항공 관제탑")
st.caption("OpenSky API 기반 항공기 관제 및 수직 승강률 기반 급강하 위험 탐지")

with st.sidebar:
    st.header("API 인증")
    use_auth = st.checkbox("OpenSky 인증 사용", value=False)
    client_id = ""
    client_secret = ""

    if use_auth:
        client_id = st.text_input("client_id")
        client_secret = st.text_input("client_secret", type="password")

        if not client_id or not client_secret:
            st.warning("인증을 사용하려면 client_id와 client_secret을 모두 입력해야 합니다.")
            st.stop()

    st.header("스캔 범위 설정")
    region_mode = st.selectbox(
        "스캔 지역",
        options=["한반도", "한반도 + 일본 서부", "동북아시아", "사용자 지정"],
        index=0,
    )

    if region_mode == "사용자 지정":
        lamin = st.number_input("최소 위도 lamin", value=33.0, min_value=-90.0, max_value=90.0, step=0.5)
        lamax = st.number_input("최대 위도 lamax", value=39.0, min_value=-90.0, max_value=90.0, step=0.5)
        lomin = st.number_input("최소 경도 lomin", value=124.0, min_value=-180.0, max_value=180.0, step=0.5)
        lomax = st.number_input("최대 경도 lomax", value=132.0, min_value=-180.0, max_value=180.0, step=0.5)
        map_zoom = st.slider("기본 지도 확대 수준", min_value=2, max_value=8, value=5)

        selected_bounds = {
            "lamin": float(lamin),
            "lomin": float(lomin),
            "lamax": float(lamax),
            "lomax": float(lomax),
            "zoom": int(map_zoom),
        }
    else:
        selected_bounds = REGION_PRESETS[region_mode]

    st.code(
        f"위도 {selected_bounds['lamin']} ~ {selected_bounds['lamax']}\n"
        f"경도 {selected_bounds['lomin']} ~ {selected_bounds['lomax']}"
    )

    st.header("관제 설정")
    refresh_seconds = st.selectbox("자동 갱신 주기", options=[10, 20, 30, 60], index=2)
    threshold = st.slider("위험 기준 Z-score", min_value=-5.0, max_value=0.0, value=-3.0, step=0.5)
    auto_refresh = st.checkbox("자동 갱신", value=True)
    focus_on_click = st.checkbox("항공기 클릭 시 지도 중심 이동", value=True)

    if st.button("즉시 갱신"):
        fetch_opensky_states.clear()
        st.rerun()

    st.info("지도 점을 클릭하면 항공기가 선택됩니다. 자동 갱신은 기본 30초입니다.")


if selected_bounds["lamin"] >= selected_bounds["lamax"]:
    st.error("최소 위도는 최대 위도보다 작아야 합니다.")
    st.stop()

if selected_bounds["lomin"] >= selected_bounds["lomax"]:
    st.error("최소 경도는 최대 경도보다 작아야 합니다.")
    st.stop()


bounds_key = (
    selected_bounds["lamin"],
    selected_bounds["lomin"],
    selected_bounds["lamax"],
    selected_bounds["lomax"],
)

if st.session_state.last_bounds_key != bounds_key:
    st.session_state.map_lat = (selected_bounds["lamin"] + selected_bounds["lamax"]) / 2
    st.session_state.map_lon = (selected_bounds["lomin"] + selected_bounds["lomax"]) / 2
    st.session_state.map_zoom = selected_bounds["zoom"]
    st.session_state.selected_icao24 = None
    st.session_state.last_bounds_key = bounds_key


status_box = st.empty()

try:
    status_box.info("OpenSky API에서 항공 데이터를 가져오는 중입니다.")
    raw_df = fetch_opensky_states(bounds_key, client_id, client_secret)
except requests.exceptions.RequestException as e:
    st.error("OpenSky API 요청에 실패했습니다.")
    st.code(str(e))
    st.stop()

if raw_df.empty:
    st.warning("현재 선택한 범위에서 조회된 항공기가 없습니다.")
    st.stop()

analysis_df = analyse_danger(raw_df, threshold)

if analysis_df.empty:
    st.warning("분석 가능한 항공기 데이터가 없습니다.")
    st.stop()

danger_df = analysis_df[analysis_df["status"] == "위험(급강하)"].copy()
updated_at = pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")
status_box.success(f"데이터 갱신 완료: {updated_at}")

metric1, metric2, metric3, metric4, metric5 = st.columns(5)

with metric1:
    st.metric("전체 수신 항공기", f"{len(raw_df)}대")

with metric2:
    st.metric("분석 대상 항공기", f"{len(analysis_df)}대")

with metric3:
    st.metric("위험 항공기", f"{len(danger_df)}대")

with metric4:
    st.metric("스캔 지역", region_mode)

with metric5:
    st.metric("갱신 주기", f"{refresh_seconds}초")

st.caption(f"현재 위험 기준: z_score <= {threshold}")

left, right = st.columns([1.15, 0.85])

with left:
    st.subheader("항공기 위치 지도")
    map_df = build_map_data(analysis_df)
    deck = make_deck(map_df)

    event = st.pydeck_chart(
        deck,
        height=650,
        width="stretch",
        on_select="rerun",
        selection_mode="single-object",
        key="aircraft_map",
    )

    selected = extract_selected_aircraft(event)

    if selected is not None:
        selected_icao24 = selected.get("icao24")

        if selected_icao24:
            st.session_state.selected_icao24 = selected_icao24

            if focus_on_click:
                new_lat = float(selected["lat"])
                new_lon = float(selected["lon"])
                new_zoom = max(st.session_state.map_zoom, 7)

                needs_focus = (
                    abs(st.session_state.map_lat - new_lat) > 0.0001 or
                    abs(st.session_state.map_lon - new_lon) > 0.0001 or
                    st.session_state.map_zoom != new_zoom
                )

                st.session_state.map_lat = new_lat
                st.session_state.map_lon = new_lon
                st.session_state.map_zoom = new_zoom

                if needs_focus:
                    st.rerun()

with right:
    st.subheader("선택 항공기")
    selected_row = analysis_df[analysis_df["icao24"] == st.session_state.selected_icao24]
    render_selected_aircraft(selected_row)

    st.subheader("위험 항공기")
    danger_columns = [
        "number", "callsign", "origin_country", "vertical_rate", "z_score",
        "baro_altitude", "velocity", "latitude", "longitude",
    ]

    if danger_df.empty:
        st.success("현재 기준에서 위험 항공기가 없습니다.")
    else:
        st.dataframe(
            danger_df[danger_columns].sort_values("z_score"),
            width="stretch",
            height=220,
        )

    st.subheader("전체 항공기")
    display_columns = [
        "number", "callsign", "status", "origin_country", "vertical_rate",
        "z_score", "baro_altitude", "velocity", "latitude", "longitude",
    ]

    st.dataframe(
        analysis_df[display_columns].sort_values("number"),
        width="stretch",
        height=300,
    )

with st.expander("원본 API 데이터"):
    st.dataframe(raw_df, width="stretch")


if auto_refresh:
    time.sleep(refresh_seconds)
    fetch_opensky_states.clear()
    st.rerun()
